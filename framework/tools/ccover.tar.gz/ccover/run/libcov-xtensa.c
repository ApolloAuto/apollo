/* $Revision: 14428 $ $Date: 2014-01-30 16:51:42 -0800 (Thu, 30 Jan 2014) $
 * Copyright (c) Bullseye Testing Technology
 * This source file contains confidential proprietary information.
 *
 * BullseyeCoverage small footprint run-time definitions for Tensilica Xtensa
 * using the Instruction Set Simulator and semi-hosted file i/o.
 */

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#include <fcntl.h>
#include <stddef.h>
#include <unistd.h>

/* open */
static int Libcov_open(const char* path, int oflag, mode_t mode)
{
	return open(path, oflag | O_BINARY, mode);
}
#define open Libcov_open

#include "atomic.h"
#include "libcov.h"
#include "version.h"
#include "libcov-core-small.h"
