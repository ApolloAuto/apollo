/* $Revision: 14428 $ $Date: 2014-01-30 16:51:42 -0800 (Thu, 30 Jan 2014) $
 * Copyright (c) Bullseye Testing Technology
 * This source file contains confidential proprietary information.
 *
 * BullseyeCoverage small footprint run-time for Green Hills Software INTEGRITY
 */

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#include <fcntl.h>
#include <stdio.h>
#include <ind_io.h>

// open
//   First try host i/o and then if that fails try native i/o
static int Libcov_open(const char* path, int oflag, int mode)
{
	int fd = hostio_open(path, oflag);
	if (fd == -1) {
		fd = open(path, oflag, mode);
	}
	return fd;
}
#define open Libcov_open

#include "atomic.h"
#include "libcov.h"
#include "version.h"
#include "libcov-core-small.h"
