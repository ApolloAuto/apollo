class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.conv.___torch_mangle_181.Conv2d
  __annotations__["1"] = __torch__.torch.nn.modules.conv.___torch_mangle_182.Conv2d
  __annotations__["2"] = __torch__.torch.nn.modules.activation.___torch_mangle_183.Sigmoid
