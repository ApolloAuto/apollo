/* $Revision: 14428 $ $Date: 2014-01-30 16:51:42 -0800 (Thu, 30 Jan 2014) $
// Copyright (c) Bullseye Testing Technology
// This source file contains confidential proprietary information.
//
// BullseyeCoverage small footprint run-time for Texas Instruments Code Composer Studio.
// This implementation uses the low-level I/O functions described in the Compiler User's Guide section
// "Using Run-Time-Support Functions and Building Libraries" : "The C I/O Functions"
*/

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#define S_IRUSR 0
#define S_IWUSR 0
#include <file.h>
#include <stddef.h>

/*---------------------------------------------------------------------------
// BullseyeCoverage run-time code
*/
#include "atomic.h"
#include "libcov.h"
#include "version.h"
#include "stub-getpid.h"
#include "libcov-core-small.h"
