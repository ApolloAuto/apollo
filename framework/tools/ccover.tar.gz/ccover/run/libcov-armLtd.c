// $Revision: 14976 $ $Date: 2014-07-23 15:15:56 -0700 (Wed, 23 Jul 2014) $
// Copyright (c) Bullseye Testing Technology
// This source file contains confidential proprietary information.
//
// BullseyeCoverage small footprint run-time for the ARM Ltd compiler

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#include <stdio.h>
#include <rt_sys.h>
#define O_CREAT 0
#define O_TRUNC 0
#define O_WRONLY OPEN_W
#define S_IRUSR 0
#define S_IWUSR 0

static int open(const char* path, int oflag, int mode)
{
	return _sys_open(path, oflag);
}

static int close(int fildes)
{
	return _sys_close(fildes);
}

static int write(int fildes, const void* buf, unsigned nbyte)
{
	int n = -1;
	// _sys_write returns number of bytes not written
	const int count = _sys_write(fildes, (const unsigned char*)buf, nbyte, OPEN_B);
	if (count >= 0) {
		n = nbyte - count;
	}
	return n;
}

#include "atomic.h"
#include "libcov.h"
#include "stub-getpid.h"
#include "version.h"
#include "libcov-core-small.h"
