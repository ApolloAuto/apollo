/* $Revision: 14676 $ $Date: 2014-04-17 11:32:06 -0700 (Thu, 17 Apr 2014) $
 * Copyright (c) Bullseye Testing Technology
 * This source file contains confidential proprietary information.
 *
 * BullseyeCoverage run-time for Unix-like operating system kernels
 * This configuration requires using a covgetkernel command to extract the data
 */

#include <stddef.h>

#include "atomic.h"
#include "libcov.h"
#include "libcov-core-kernel.h"
