// $Revision: 17229 $ $Date: 2017-07-11 15:17:09 -0700 (Tue, 11 Jul 2017) $
// Copyright (c) Bullseye Testing Technology
// This source file contains confidential proprietary information.

// Provides /proc/BullseyeCoverage file, which implements an interface similar
//   to /dev/kmem, except reading at low offsets return special values
//   and writing is restricted to zeros within cov_array.
// This supports both module and kernel image.

#if defined(__GNUC__) && __GNUC__ >= 4
	#pragma GCC diagnostic ignored "-Wundef"
#endif

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#include <linux/init.h>
#include <linux/module.h>
#include <linux/notifier.h>
#include <linux/proc_fs.h>
#include <linux/version.h>
#include <linux/elf.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,12,0)
	#include <asm/uaccess.h>
#else
	#include <linux/uaccess.h>
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	#error Version prior to 2.6 not supported
#endif

#if !defined(__user)
	#define __user
#endif

#include "../atomic.h"
#include "../libcov.h"
#include "../libcov-core-kernel.h"

static cov_atomic_t fileOpenLock = cov_atomic_initializer;
static int isNegativeOffset;

// Export symbols
#if defined(EXPORT_SYMBOL_NOVERS)
	#define libcov_export(x) EXPORT_SYMBOL_NOVERS(x)
#else
	#define libcov_export(x) EXPORT_SYMBOL(x)
#endif
libcov_export(Libcov_probe);
libcov_export(cov_check);
libcov_export(cov_countDown);
libcov_export(cov_countUp);
libcov_export(cov_reset);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,29)
	static inline int within_module_core(unsigned long addr, struct module *mod)
	{
		return (unsigned long)mod->module_core <= addr &&
			addr < (unsigned long)mod->module_core + mod->core_size;
	}
#endif

static struct notifier_block notifier_blk;

static int notifier_callback(struct notifier_block* this_, unsigned long state, void* p)
{
	if (state == MODULE_STATE_GOING) {
		const struct module* module = p;
		unsigned i;
		for (i = 1; i < sizeof(cov_array) / sizeof(cov_array[0]); i++) {
			const unsigned long objAddr = (unsigned long)cov_array[i];
			if (within_module_core(objAddr, module)) {
				cov_array[i] = NULL;
			}
		}
	}
	return 0;
}

static int proc_file_open(struct inode* inode, struct file* file)
{
	int status = -EBUSY;
	// If file not already open
	if (cov_atomic_tryLock(&fileOpenLock)) {
		status = 0;
		isNegativeOffset = 0;
		printk(KERN_INFO "BullseyeCoverage: main array at %p\n", cov_array);
	}
	return status;
}

// Need seek implementation because default one limits offset range.
static loff_t proc_file_lseek(struct file* file, loff_t offset, int whence)
{
	switch (whence) {
	case 1:
		offset += file->f_pos;
		//lint -fallthrough
	case 0:
		file->f_pos = offset;
		// read system call does not allow negative offsets
		isNegativeOffset = offset < 0;
		if (isNegativeOffset) {
			file->f_pos = -file->f_pos;
		}
		break;
	default:
		offset = -EINVAL;
		break;
	}
	return offset;
}

static ssize_t proc_file_read(struct file* file, char __user* buf, size_t size, loff_t* ppos)
{
	size_t count;
	unsigned long address = (unsigned long)*ppos;
	if (isNegativeOffset) {
		address = (unsigned long)-*ppos;
	}
	// If special address
	if (address <= 3 + sizeof(long)) {
		char bufLocal[sizeof(long)];
		count = -EINVAL;
		switch (address) {
		case 0:
			// Return protocol version
			if (size == 1) {
				bufLocal[0] = 5;
				count = 1;
			}
			break;
		case 1:
			// Return elf machine type
			if (size == 1) {
				bufLocal[0] = ELF_ARCH;
				count = 1;
			}
			break;
		case 2:
			// Whether address validation is working
			if (size == 1) {
				bufLocal[0] = 1;
				count = 1;
			}
			break;
		case 3:
			// Return address of cov_kernel
			if (size == sizeof(long)) {
				const unsigned long offset = (unsigned long)&cov_kernel;
				memcpy(bufLocal, &offset, sizeof(long));
				count = sizeof(long);
			}
		case 3 + sizeof(long):
			if (size == 1) {
				cov_reset();
				bufLocal[0] = 0;
				count = 1;
			}
			break;
		default:
			count = -EFAULT;
			break;
		}
		if ((ssize_t)count > 0 && copy_to_user(buf, bufLocal, count) == 0) {
			// Update file pointer
			*ppos += count;
		}
	} else {
		count = -EFAULT;
		if (copy_to_user(buf, (void*)address, size) == 0) {
			count = size;
			// Update file pointer
			*ppos = address + size;
			if (isNegativeOffset) {
				*ppos = -*ppos;
			}
		}
	}
	return count;
}

// Write is only used to zero out a bad pointer in cov_array
static ssize_t proc_file_write(struct file* file, const char __user* buf, size_t size, loff_t* ppos)
{
	size_t count = -EFAULT;
	unsigned long address = (unsigned long)*ppos;
	if (isNegativeOffset) {
		address = (unsigned long)-*ppos;
	}
	// Restrict valid address to cov_array[1..n-1]
	if (size == sizeof(long) &&
		address >= (unsigned long)(cov_array + 1) &&
		address <= (unsigned long)cov_array + sizeof(cov_array) - sizeof(cov_array[0]))
	{
		// Just write zero directly, instead of from user buf
		memset((void*)address, 0, sizeof(long));
		count = sizeof(long);
	}
	return count;
}

static int proc_file_release(struct inode* inode, struct file* file)
{
	cov_atomic_unlock(&fileOpenLock);
	return 0;
}

static struct file_operations proc_file_ops = {
	.owner   = THIS_MODULE,
	.open    = proc_file_open,
	.llseek  = proc_file_lseek,
	.read    = proc_file_read,
	.write   = proc_file_write,
	.release = proc_file_release
};

static const char procFilename[] = "BullseyeCoverage";

static int libcov_init(void)
{
	int status = -ENOENT;
	// Create /proc entry
	#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,0,0)
		if (proc_create(procFilename, 0600, NULL, &proc_file_ops)) {
			status = 0;
		}
	#else
		struct proc_dir_entry* entry =
			create_proc_entry(procFilename, 0600, NULL);
		if (entry != NULL) {
			entry->proc_fops = &proc_file_ops;
			status = 0;
		}
	#endif
	notifier_blk.notifier_call = notifier_callback;
	register_module_notifier(&notifier_blk);
	printk(KERN_INFO "BullseyeCoverage: kernel run-time init %s\n",
		status == 0 ? "succeeded" : "failed");
	return status;
}

static void libcov_exit(void)
{
	remove_proc_entry(procFilename, NULL);
	unregister_module_notifier(&notifier_blk);
	printk(KERN_INFO "BullseyeCoverage: kernel run-time unloaded\n");
}

module_init(libcov_init)
module_exit(libcov_exit)
