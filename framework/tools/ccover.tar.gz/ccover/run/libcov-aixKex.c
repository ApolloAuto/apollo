/* $Revision: 14677 $ $Date: 2014-04-17 15:42:00 -0700 (Thu, 17 Apr 2014) $
 * Copyright (c) Bullseye Testing Technology
 * This source file contains confidential proprietary information.
 *
 * AIX kernel extension entry point function for loading BullseyeCoverage run-time as a kernel extension
 */

#include <syslog.h>
#include <sys/device.h>

int __start(int cmd, struct uio* uio)
{
        if (cmd == CFG_INIT) {
                bsdlog(LOG_DEBUG | LOG_KERN, "BullseyeCoverage run-time init\n");
        } else if (cmd == CFG_TERM) {
                bsdlog(LOG_DEBUG | LOG_KERN, "BullseyeCoverage run-time term\n");
        }
        return 0;
}
