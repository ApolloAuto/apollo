class SmoothL1Loss(Module):
  __parameters__ = []
  training : bool
