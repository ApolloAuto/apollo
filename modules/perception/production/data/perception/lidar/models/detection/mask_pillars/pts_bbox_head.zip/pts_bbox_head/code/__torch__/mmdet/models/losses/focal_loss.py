class FocalLoss(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
