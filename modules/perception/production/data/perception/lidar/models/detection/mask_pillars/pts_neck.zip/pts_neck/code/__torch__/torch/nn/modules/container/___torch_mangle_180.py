class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.container.___torch_mangle_171.Sequential
  __annotations__["1"] = __torch__.torch.nn.modules.container.___torch_mangle_175.Sequential
  __annotations__["2"] = __torch__.torch.nn.modules.container.___torch_mangle_179.Sequential
