/* $Revision: 13315 $ $Date: 2012-12-03 17:35:04 -0800 (Mon, 03 Dec 2012) $
 * Copyright (c) Bullseye Testing Technology
 */

#define getpid Libcov_getpid
static int getpid(void)
{
	return 1;
}
