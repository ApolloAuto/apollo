/* $Revision: 15558 $ $Date: 2015-05-12 07:53:45 -0700 (Tue, 12 May 2015) $
// Copyright (c) Bullseye Testing Technology
// Copyright (c) Qualcomm 2012-2013
// This source file contains confidential proprietary information.
//
// BullseyeCoverage small footprint run-time for UEFI
*/

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#include <Uefi.h>
#include <Library/DebugLib.h>

#define O_CREAT 0
#define O_TRUNC 0
#define O_WRONLY 0
#define S_IRUSR 0
#define S_IWUSR 0

typedef int ssize_t;

static int open(const char* path, int oflag, int mode)
{
	DEBUG(EFI_D_WARN, "--- BullseyeCoverage begin file '%a' ---\n", path);
	return 3;
}

static int close(int fildes)
{
	DEBUG(EFI_D_WARN, "--- BullseyeCoverage end of file ---\n");
	return 0;
}

static int write(int fildes, const void* buf, unsigned nbyte)
{
	unsigned i;
	const char* s = (const char*)buf;
	for (i = 0; i < nbyte; i++) {
		if (s[i] == '\n') {
			DEBUG(EFI_D_WARN, "\r\n");
		} else {
			DEBUG(EFI_D_WARN, "%c", s[i]);
		}
	}
	return (int)nbyte;
}

#include "atomic.h"
#include "libcov.h"
#include "version.h"
#include "stub-getpid.h"
#include "libcov-core-small.h"
