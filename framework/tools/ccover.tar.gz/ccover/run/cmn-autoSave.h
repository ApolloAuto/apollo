/* $Revision: 17153 $ $Date: 2017-05-08 15:23:31 -0700 (Mon, 08 May 2017) $
 * Copyright (c) Bullseye Testing Technology
 * This source file contains confidential proprietary information.
 */

#if __cplusplus
	extern "C" {
#endif

/* Set this to 0 to prevent the auto-save thread creation. */
int cov_autoSave = 1;

#if __cplusplus
	}
#endif

#if Libcov_noAutoSave || Libcov_dynamic
	static int autoSave_create(void)
	{
		return 0;
	}

	static int autoSave_join(void)
	{
		return 0;
	}
#else
	static pthread_t autoSave_pthread;
	static volatile char autoSave_isRun;
	static volatile int autoSave_pthread_isValid;

	#if !defined(PTHREAD_LINK)
		#define PTHREAD_LINK
	#endif
	static void* PTHREAD_LINK autoSave_thread(void* arg)
	{
		unsigned count = 0;
		#if !_WIN32 && (_AIX || __APPLE__ || __FreeBSD__ || __hpux || __linux || __sgi || __sun || \
				defined(_POSIX_C_SOURCE) || defined(_XOPEN_SOURCE) || defined(SIG_SETMASK))
			/* Block all signals */
			sigset_t signalMask;
			sigfillset(&signalMask);
			pthread_sigmask(SIG_SETMASK, &signalMask, NULL);
		#endif
		while (autoSave_isRun) {
			/* Sleep for 1/10th second, practically imperceptible to a human */
			struct timespec rqt;
			int status;
			rqt.tv_sec = 0;
			rqt.tv_nsec = 100000000;
			/*   Repeat if interrupted by a signal */
			do {
				status = nanosleep(&rqt, NULL);
			} while (status != 0 && errno == EINTR);
			/*   If nanosleep is not working */
			if (status != 0) {
				/* Bail out rather than consume the CPU */
				break;
			}
			/* Call cov_write every 10 loops, making once per second */
			count++;
			if (count == 10 && autoSave_isRun) {
				cov_write();
				count = 0;
			}
		}
		autoSave_pthread_isValid = 0;
		pthread_exit(NULL);
		arg = arg;
		return NULL;
	}

	static int autoSave_create(void)
	{
		int status = 0;
		static int isAutoSave;
		static int isAutoSaveSet;
		if (!isAutoSaveSet) {
			const char* p = getenv("COVAUTOSAVE");
			if ((p == NULL || p[0] != '0' || p[1] != '\0')) {
				isAutoSave = 1;
			}
			isAutoSaveSet = 1;
		}
		if (isAutoSave && cov_autoSave) {
			autoSave_isRun = 1;
			status = pthread_create(&autoSave_pthread, NULL, autoSave_thread, NULL);
			autoSave_pthread_isValid = status == 0;
		}
		return status;
	}

	#if !_AIX
	/* Wait maximum 5 seconds, in case the thread is not running at all.
	// If we give up too soon, valgrind --leak-check=full reports a memory leak by pthread_create.
	*/
	static int autoSave_join_nanosleep(void)
	{
		int status = 0;
		unsigned count;
		struct timespec rqt;
		rqt.tv_sec = 0;
		rqt.tv_nsec = 10000000;	/* 0.01s */
		for (count = 0; autoSave_pthread_isValid && count < 500; count++) {
			status = nanosleep(&rqt, NULL);
			if (status != 0) {
				break;
			}
		}
		if (status == 0 && autoSave_pthread_isValid) {
			status = -1;
		}
		return status;
	}
	#endif

	static int autoSave_join(void)
	{
		int status = 0;
		autoSave_isRun = 0;
		#if _AIX
			/* On AIX 5.1, pthread_join and nanosleep incorrectly let a blocked signal be delivered
			// Do nothing. The thread will be cleaned up when the application terminates
			*/
		#elif Libcov_posix
			/* Function pthread_join never returns on the systems listed below. Use nanosleep instead
			// - uclibc
			// - DENX Embedded Linux Development Kit 4.2 ppc_4xx
			*/
			status = autoSave_join_nanosleep();
		#else
			if (autoSave_pthread_isValid) {
				status = pthread_join(autoSave_pthread, NULL);
			}
			if (autoSave_pthread_isValid) {
				/* pthread_join failed, try nanosleep */
				const int status2 = autoSave_join_nanosleep();
				if (status == 0) {
					status = status2;
				}
			}
		#endif
		return status;
	}
#endif
