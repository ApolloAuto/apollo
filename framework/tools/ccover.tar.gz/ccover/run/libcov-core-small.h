// $Revision: 17052 $ $Date: 2017-03-27 14:25:57 -0700 (Mon, 27 Mar 2017) $
// Copyright (c) Bullseye Testing Technology
// This source file contains confidential proprietary information.
//
// BullseyeCoverage small footprint run-time for embedded systems core definitions
//
// Do not modify this file. See instructions: www.bullseye.com/help/env-embedded.html

#if __GNUC__ * 100 + __GNUC_MINOR__ >= 401
	#pragma GCC diagnostic ignored "-Wpointer-to-int-cast"
	#pragma GCC diagnostic ignored "-Wconversion"
#endif

#if __cplusplus
extern "C" {
#endif

static unsigned short constructorCount;
static short error;
static const CovObject* volatile cov_list;
static cov_atomic_t cov_list_lock = cov_atomic_initializer;
static int fildes = -1;
static unsigned outputLength;
/* Multi purpose buffer, shared to conserve memory */
static char buf[128];
static unsigned char buf_index;

/* Append a string to the shared buffer */
static void stringCopy(const char* string)
{
	unsigned char i;
	for (i = 0; string[i] != '\0' && buf_index < sizeof(buf) - 1; i++) {
		buf[buf_index++] = string[i];
	}
	buf[buf_index] = '\0';
}

static void error_report(short errorNumber, const char* arg)
{
	const char* string;
	error = errorNumber;
	buf_index = 0;
	stringCopy(VERSION_title ": ");
	switch (error) {
	case 5:  string = "error 5: i/o error"; break;
	case 23: string = "error 23: memory corrupt in .bss"; break;
	case 24: string = "error 24: memory corrupt in .const"; break;
	case 26: string = "error 26: cannot open file"; break;
	default: string = "error unknown"; break;
	}
	stringCopy(string);
	if (arg != NULL) {
		stringCopy(", ");
		stringCopy(arg);
	}
	stringCopy("\n");
	write(2, buf, buf_index);
}

int cov_check(void)
{
	int status;
	unsigned count = 0;
	const CovObject* p;
	/* Do not lock cov_list_lock because this function does not modify cov_list */
	for (p = cov_list; error == 0 && p != NULL; p = p->var->next) {
		if (p->signature != CovObject_signature || p->data_n == 0) {
			error_report(24, "check");
		} else {
			unsigned i;
			const CovVar* var = p->var;
			for (i = 0; i < p->data_n && var->data[i] <= 1; i++)
				;
			if (i < p->data_n || var->events_written != 0 || var->is_linked != 1 || var->is_found != 0) {
				error_report(23, "check1");
			}
		}
		if (count == 0xffff) {
			/* There is a cycle in the chain, which happens when CovVar.is_linked was corrupted
			// (by being cleared) causing a CovObject to be add to the chain more than once.
			*/
			error_report(23, "check2");
			break;
		}
		count++;
	}
	status = error;
	if (status == 0) {
		status = -(int)count;
	}
	return status;
}

unsigned cov_eventCount(void)
{
	unsigned count = 0;
	const CovObject* p;
	for (p = cov_list; p != NULL; p = p->var->next) {
		const unsigned char* data = p->var->data;
		unsigned i = p->data_n;
		do {
			i--;
			count += data[i];
		} while (i != 0);
	}
	return count;
}

int cov_reset(void)
{
	const int status = cov_check();
	if (status < 0) {
		/* Wait for the cov_list lock */
		while (!cov_atomic_tryLock(&cov_list_lock))
			;
		{
			const CovObject* p = cov_list;
			cov_list = NULL;
			while (p != NULL) {
				CovVar* var = p->var;
				const CovObject* next = var->next;
				unsigned i;
				for (i = 0; i < p->data_n; i++) {
					var->data[i] = 0;
				}
				var->is_linked = 0;
				var->next = NULL;
				p = next;
			}
		}
		cov_atomic_unlock(&cov_list_lock);
	}
	return status;
}

static void error_report_limit(short errorNumber, const char* arg)
{
	static unsigned char count;
	if (count < 10) {
		error_report(errorNumber, arg);
		count++;
	}
}

// Prototype for MISRA
void Libcov_probe(const void* p_void, int probe);
void Libcov_probe(const void* p_void, int probe)
{
	const CovObject* p = (const CovObject*)p_void;
	if (p->signature != CovObject_signature || (unsigned)probe >= p->data_n) {
		error_report_limit(24, "probe");
	} else {
		CovVar* var = p->var;
		var->data[probe] = 1;
		if (!var->is_linked && cov_atomic_tryLock(&cov_list_lock)) {
			if (!var->is_linked) {
				/* Check to see if this object is already in the chain */
				const CovObject* q;
				for (q = cov_list; q != NULL; q = q->var->next) {
					if (q->signature != CovObject_signature) {
						break;
					}
					if (q == p) {
						break;
					}
				}
				var->is_linked = 1;
				/* If not found */
				if (q == NULL) {
					var->next = cov_list;
					cov_list = p;
				} else {
					error_report_limit(23, "probe");
				}
			}
			cov_atomic_unlock(&cov_list_lock);
		}
	}
}

static void write_errorCheck(const char* s, unsigned nbyte)
{
	if (error == 0 && write(fildes, s, nbyte) != (int)nbyte) {
		error_report(5, NULL);
	}
	outputLength += nbyte;
}

/* Format a number as decimal */
static void formatNumber(unsigned long n)
{
	unsigned char length;
	/* Go backwards with rightmost digit in rightmost buffer position */
	unsigned char i = sizeof(buf);
	unsigned char j;
	do {
		i--;
		buf[i] = (char)('0' + n % 10);
		n /= 10;
	} while (n != 0);
	length = sizeof(buf) - i;
	/* Slide results left */
	for (j = 0; j < length; j++) {
		buf[buf_index++] = buf[i++];
	}
	buf[buf_index] = '\0';
}

/* Write a number followed by a new-line */
static void writeNumber(unsigned long n)
{
	buf_index = 0;
	formatNumber(n);
	stringCopy("\n");
	write_errorCheck(buf, buf_index);
}

/* Encode a value 0..63 as a base 64 character */
static char base64_encode(unsigned char value)
{
	char c;
	if (value < 12) {
		c = (char)(value + '0');
	} else if (value < 12 + 26) {
		c = (char)(value + 'A' - 12);
	} else {
		c = (char)(value + 'a' - 12 - 26);
	}
	return c;
}

static void dumpPart(unsigned limit)
{
	/* Current object */
	static const CovObject* ob;
	/* Index to ob->data[] */
	static unsigned di;
	/* Maximum length of basename line */
	enum { basenameSize = 32 + sizeof(" ddmmm hh:mm") };
	/* Maximum number of event data characters per line */
	enum { dataLength = 64 };
	/* Estimated size of next line */
	unsigned char nextSize = 0;
	outputLength = 0;
	do {
		static unsigned char state;
		switch (state) {
		case 0:
			/* Open output file and write file header */
			{
				buf_index = 0;
				stringCopy("BullseyeCoverage.data-");
				formatNumber((unsigned long)getpid());
				fildes = open(buf, O_CREAT | O_TRUNC | O_WRONLY, S_IRUSR | S_IWUSR);
				if (fildes == -1) {
					error_report(26, NULL);
				} else {
					/* Write file identification */
					static const char s[] = "BullseyeCoverage S3\n";
					write_errorCheck(s, sizeof(s) - 1);
					state = 1;
					nextSize = basenameSize;
					ob = cov_list;
					di = 0;
				}
			}
			break;
		case 1:
			/* Write basename */
			buf_index = 0;
			stringCopy(ob->basename);
			stringCopy("\n");
			buf[sizeof(buf) - 2] = '\n';
			write_errorCheck(buf, buf_index);
			state = 2;
			nextSize = 2 * sizeof("9223372036854775807") + sizeof("999999");
			break;
		case 2:
			/* Write fileId, id, data_n */
			writeNumber(ob->fileId);
			writeNumber(ob->id);
			writeNumber(ob->data_n);
			state = 3;
			nextSize = dataLength + 1;
			break;
		case 3:
			/* Write one line of event data */
			for (buf_index = 0; buf_index < dataLength && di < ob->data_n; buf_index++) {
				unsigned char j;
				unsigned char value = 0;
				for (j = 0; j < 6; j++) {
					value <<= 1;
					if (di < ob->data_n) {
						value |= ob->var->data[di++];
					}
				}
				buf[buf_index] = base64_encode(value);
			}
			stringCopy("\n");
			write_errorCheck(buf, buf_index);
			/* If end of data */
			if (di == ob->data_n) {
				ob = ob->var->next;
				di = 0;
				if (ob == NULL) {
					state = 4;
					nextSize = sizeof("end");
				} else {
					state = 1;
					nextSize = basenameSize;
				}
			}
			break;
		default:
			write_errorCheck("end\n", 4);
			close(fildes);
			fildes = -1;
			state = 0;
			break;
		}
		if (error != 0 && fildes != -1) {
			close(fildes);
			fildes = -1;
		}
	} while (outputLength + nextSize <= limit && fildes != -1);
}

// Prototype for MISRA
int cov_dumpPart(unsigned limit, int* error_ptr);
int cov_dumpPart(unsigned limit, int* error_ptr)
{
	if (error == 0 && cov_list != NULL) {
		static cov_atomic_t lock = cov_atomic_initializer;
		if (cov_atomic_tryLock(&lock)) {
			dumpPart(limit);
			cov_atomic_unlock(&lock);
		}
	}
	if (error == 0 && cov_list == NULL) {
		*error_ptr = 20;
	} else {
		*error_ptr = error;
	}
	return fildes != -1;
}

// Prototype for MISRA
int cov_dumpData(void);
int cov_dumpData(void)
{
	int e;
	cov_check();
	while (cov_dumpPart(~0u, &e))
		;
	return e;
}

// Prototype for MISRA
void cov_countDown(void);
void cov_countDown(void)
{
	constructorCount--;
	if (constructorCount == 0) {
		cov_dumpData();
	}
}

// Prototype for MISRA
void cov_countUp(void);
void cov_countUp(void)
{
	constructorCount++;
}

void cov_term(void)
{
	cov_dumpData();
}

#if __cplusplus
}
#endif
