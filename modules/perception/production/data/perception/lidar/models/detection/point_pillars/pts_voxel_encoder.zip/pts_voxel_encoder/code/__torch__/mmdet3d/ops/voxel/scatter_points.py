class DynamicScatter(Module):
  __parameters__ = []
  training : bool
