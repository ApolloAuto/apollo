class CrossEntropyLoss(Module):
  __parameters__ = []
  training : bool
