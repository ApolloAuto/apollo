/* $Revision: 17223 $ $Date: 2017-07-03 10:16:59 -0700 (Mon, 03 Jul 2017) $
 * Copyright (c) Bullseye Testing Technology
 * This source file contains confidential proprietary information.
 */

#include "cmn-getenvBuf.h"

/* Environment variables are read from a plain text file, which has the form:
//   name1=value1
//   name2=value2
//   ...
*/
static char* getenvFile(const char* name, const char* path)
{
	/* Buffer containing return value */
	static char buf[1024];
	/* Length of data read into buf */
	static unsigned n;
	static int isOnce;
	if (!isOnce) {
		/* File descriptor */
		const int fd = open(path, O_RDONLY, 0);
		/* Read whole file into buf */
		if (fd != -1) {
			const int nbyte = (int)read(fd, buf, sizeof(buf) - 1);
			if (nbyte > 0) {
				n = (unsigned)nbyte;
			}
			close(fd);
		}
	}
	return getenvBuf(name, buf, n);
}
