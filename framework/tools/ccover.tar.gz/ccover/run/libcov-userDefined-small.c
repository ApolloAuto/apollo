// $Revision: 15932 $ $Date: 2015-11-30 09:27:51 -0800 (Mon, 30 Nov 2015) $
// Copyright (c) Bullseye Testing Technology
// This source file contains confidential proprietary information.
//
// BullseyeCoverage small footprint run-time porting layer
// http://www.bullseye.com/help/env-embedded.html
//
// Implementations should conform to the Single UNIX Specification
// http://www.opengroup.org/onlinepubs/009695399/

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

//---------------------------------------------------------------------------
// NULL
// Change the line below to "#if 0" if you do not have stdlib.h
#if 1
	#include <stdlib.h>
#else
	#define NULL 0
#endif

//---------------------------------------------------------------------------
// open, close, write
// Change the line below to "#if 0" if you do not have these headers
#if 1
	#include <fcntl.h>
	#include <sys/stat.h>
	#include <unistd.h>
	#if !defined(O_CREAT)
		#error O_CREAT not defined
	#endif
	#if !defined(S_IRUSR)
		#error S_IRUSR not defined
	#endif
#else
	// http://pubs.opengroup.org/onlinepubs/009695399/functions/open.html
	// http://pubs.opengroup.org/onlinepubs/009695399/functions/close.html
	// http://pubs.opengroup.org/onlinepubs/009695399/functions/write.html
	#define O_CREAT 0x0100
	#define O_TRUNC 0x0200
	#define O_WRONLY 1
	#define S_IRUSR 0x0100
	#define S_IWUSR 0x0080

	int getpid(void)
	{
		// If you have multiple instrumented programs running simultaneously,
		// this function should return a different value for each of them.
		// Otherwise, return any value.
		return 1;
	}

	int open(const char* path, int oflag, int mode)
	{
		// Insert your code here. Successful return is > 2
		return -1;
	}

	int close(int fildes)
	{
		// Insert your code here. The return value is not used.
		return 0;
	}

	int write(int fildes, const void* buf, unsigned nbyte)
	{
		if (fildes == 2) {
			// Insert your code here to report the error message in buf.
			// This is critical. Implement this first.
			// The message ends with a newline.
			// A null character follows the buffer (buf[nbyte] == '\0').
		} else {
			// Insert your code here to write data
		}
		// Successful return is number of bytes written >= 0
		return -1;
	}
#endif

//---------------------------------------------------------------------------
// BullseyeCoverage run-time code
#include "atomic.h"
#include "libcov.h"
#include "version.h"
#include "libcov-core-small.h"
