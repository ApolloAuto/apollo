/* $Revision: 16352 $ $Date: 2016-07-15 17:19:47 -0700 (Fri, 15 Jul 2016) $
// Copyright (c) Bullseye Testing Technology
// This source file contains confidential proprietary information.
//
// BullseyeCoverage small footprint run-time for systems with a simple debug printing capability
//
// Transfer the text between, but not including, the lines beginning with --- into the file named in the first line.
// For the example output below, create a file named BullseyeCoverage.data-1 containing the text from "BullseyeCoverage" to "end":
// Do not include the lines beginning with "---".
//
//   --- BullseyeCoverage begin file 'BullseyeCoverage.data-1', data begins next line ---
//   BullseyeCoverage S3
//   #4223620
//   calc1.o 12May15 18:41
//   1605020333
//   3978996398
//   40
//   rxK0s88
//   end
//   --- BullseyeCoverage end file ---
*/

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#include <stdio.h>

#define O_CREAT 0
#define O_TRUNC 0
#define O_WRONLY 0
#define S_IRUSR 0
#define S_IWUSR 0

static int getpid(void)
{
	return 1;
}

static int open(const char* path, int oflag, int mode)
{
	printf("--- BullseyeCoverage begin file '%s', data begins next line ---\n", path);
	return 3;
}

static int close(int fildes)
{
	printf("--- BullseyeCoverage end file ---\n");
	return 0;
}

static int write(int fildes, const void* buf, unsigned nbyte)
{
	printf("%s", (const char*)buf);
	return (int)nbyte;
}

#include "atomic.h"
#include "libcov.h"
#include "version.h"
#include "libcov-core-small.h"
